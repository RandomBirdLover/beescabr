# =============================================================
# pipelines/ingest_inat.R
# beescabr pipeline -- populate the DuckDB observation cache from the API
# Created: 2026-07-13 (API + DuckDB rewrite)
#
# THE ONE PLACE that fetches observations. Both native_bee_checklist.R and
# inat_bee_clean.R depend on the cache this fills, but neither performs a
# fetch itself -- so a manual DB query, the checklist, and the clean script
# all see identical data, refreshed once. This replaces the retired CSV
# export entirely.
#
# Incremental by default: resumes from the highest stored observation id
# (iNat ids are monotonic, so id_above paging only pulls what's new since
# the last run). Pass incremental = FALSE to re-walk the full place.
#
# Depends on: api/inat_http.R, db/store_conn.R, db/observations_store.R,
# config.R.
# =============================================================

if (!exists("inat_paginate_observations")) source("scripts/api/inat_http.R")
if (!exists("write_observations"))          source("scripts/db/observations_store.R")
if (!exists("TAXON_ANTHOPHILA"))            source("scripts/config.R")

# ------------------------------------------------------------
# ingest_observations(): fetch all matching observations into the cache.
# Scope mirrors the retired export + the Python query: all Anthophila in
# the SD County buffer place, excluding Apis mellifera.
# Returns the number of observations fetched this run.
# ------------------------------------------------------------
# `flush_rows` controls the bulk-transaction size: observations are buffered
# across pages and written in ONE transaction (one set-based INSERT + one
# COMMIT) each time the buffer reaches this many rows. Fewer, larger commits
# are dramatically faster than committing every 200-row page, while periodic
# flushing keeps the incremental id cursor durable if a long run is
# interrupted. Tune up for speed, down for more frequent checkpoints.
ingest_observations <- function(con,
                                place_id = PLACE_SD_COUNTY_BUFFER,
                                taxon_id = TAXON_ANTHOPHILA,
                                without_taxon_id = TAXON_APIS_MELLIFERA,
                                incremental = TRUE,
                                extra_query = list(),
                                flush_rows = 5000L,
                                request_fn = inat_request,
                                verbose = TRUE) {
  query <- c(list(
    place_id         = place_id,
    taxon_id         = taxon_id,
    without_taxon_id = without_taxon_id
  ), extra_query)

  start_id <- if (incremental) max_observation_id(con) else 0L
  if (verbose) {
    message(sprintf("Ingest: place_id=%s taxon_id=%s (exclude %s) | %s from id_above=%d | flush every %d rows",
                    place_id, taxon_id, without_taxon_id,
                    if (incremental) "incremental" else "full", start_id, flush_rows))
  }

  buffer    <- list()   # accumulated observation objects across pages
  n_written <- 0L

  # Write the current buffer in a single transaction, then clear it.
  flush_buffer <- function() {
    if (length(buffer) == 0) return(invisible())
    DBI::dbBegin(con)
    ok <- FALSE
    tryCatch({
      write_observations(con, buffer)
      DBI::dbCommit(con)
      ok <- TRUE
    }, finally = if (!ok) DBI::dbRollback(con))
    n_written <<- n_written + length(buffer)
    if (verbose) message(sprintf("  committed batch -> %d rows persisted so far", n_written))
    buffer <<- list()
  }

  fetched <- inat_paginate_observations(
    query    = query,
    callback = function(results) {
      buffer <<- c(buffer, results)
      if (length(buffer) >= flush_rows) flush_buffer()
    },
    start_id   = start_id,
    request_fn = request_fn,
    verbose    = verbose
  )
  flush_buffer()  # final partial batch

  if (verbose) {
    message(sprintf("Ingest complete: %d fetched, %d written. Cache now holds %d observations.",
                    fetched, n_written, count_observations(con)))
  }
  invisible(fetched)
}
