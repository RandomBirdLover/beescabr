# =============================================================
# db/observations_store.R
# beescabr pipeline -- observation object repository (DuckDB)
# Created: 2026-07-13 (API + DuckDB rewrite)
#
# Stores raw iNat observation JSON with an extracted spatial `location`
# geometry column so ad-hoc manual queries (ST_Within / ST_DWithin against
# a boundary or point) run directly on the DB without parsing JSON. Only
# the id, taxon_id, observed_on, lat/long and geometry are promoted to
# columns; everything else stays in raw_data and is reconstructed by the
# flatten layer on read.
#
# This repo is the CACHE. Populating it from the API is the ingest
# pipeline's job (pipelines/ingest_inat.R); consuming it into an
# export-shaped frame is pipelines/read_inat.R's job.
#
# Depends on: DBI, duckdb, jsonlite. Assumes spatial extension already
# loaded by store_connect().
# =============================================================

library(DBI)

# ------------------------------------------------------------
# write_observations(): bulk-upsert a batch of raw observation objects (a
# list of nested lists, straight from the API) into inat_observations in ONE
# set-based INSERT. Pass as many observations as you can buffer -- the ingest
# loop hands this many pages at once so a single statement covers thousands
# of rows.
#
# Performance notes:
#   - The raw JSON is CAST once (CTE `s`) and coordinates extracted once
#     (CTE `c`), instead of re-parsing the JSON string for every column.
#   - Geometry is built with ST_Point(lon, lat) from the already-extracted
#     DOUBLE coordinates -- far cheaper than TRY(ST_GeomFromGeoJSON(...)),
#     which would parse the GeoJSON string a second time per row. Stored in
#     EPSG:4326 (lon/lat) as before.
#   - Does NOT manage a transaction itself; the caller wraps a whole batch in
#     one dbBegin()/dbCommit() so commit/checkpoint cost is amortized.
# ------------------------------------------------------------
write_observations <- function(con, results) {
  if (length(results) == 0) return(invisible(0L))

  raw_json <- vapply(results, function(o) jsonlite::toJSON(o, auto_unbox = TRUE, null = "null"),
                     character(1))
  stg <- data.frame(raw = raw_json, stringsAsFactors = FALSE)

  duckdb::duckdb_register(con, "stg_obs", stg)
  on.exit(duckdb::duckdb_unregister(con, "stg_obs"), add = TRUE)

  DBI::dbExecute(con, "
    INSERT OR REPLACE INTO inat_observations
    WITH s AS (SELECT CAST(raw AS JSON) AS j FROM stg_obs),
    c AS (
      SELECT j,
        CAST(j->>'$.id' AS BIGINT)                            AS id,
        TRY_CAST(j->>'$.taxon.id' AS BIGINT)                 AS taxon_id,
        TRY_CAST(j->>'$.observed_on' AS DATE)                AS observed_on,
        TRY_CAST(j->>'$.geojson.coordinates[1]' AS DOUBLE)   AS lat,
        TRY_CAST(j->>'$.geojson.coordinates[0]' AS DOUBLE)   AS lon
      FROM s
    )
    SELECT
      id, taxon_id, observed_on, lat, lon,
      CASE WHEN lon IS NOT NULL AND lat IS NOT NULL
           THEN ST_Point(lon, lat) ELSE NULL END,
      j
    FROM c
    WHERE id IS NOT NULL;
  ")
  invisible(length(results))
}

# ------------------------------------------------------------
# Read helpers.
# ------------------------------------------------------------
count_observations <- function(con) {
  DBI::dbGetQuery(con, "SELECT COUNT(*) AS n FROM inat_observations")$n[1]
}

# Highest stored observation id -- the incremental fetch cursor. 0 when empty.
max_observation_id <- function(con) {
  v <- DBI::dbGetQuery(con, "SELECT MAX(id) AS m FROM inat_observations")$m[1]
  if (is.na(v)) 0L else as.integer(v)
}

# Return raw observation JSON strings (id + raw_data) for the flatten layer.
read_observations_raw <- function(con) {
  DBI::dbGetQuery(con, "SELECT id, raw_data FROM inat_observations ORDER BY id")
}
