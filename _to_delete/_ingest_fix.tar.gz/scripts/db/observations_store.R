# =============================================================
# db/observations_store.R
# beescabr pipeline -- observation object repository (DuckDB)
# Created: 2026-07-13 (API + DuckDB rewrite)
#
# Stores raw iNat observation JSON with an extracted spatial `location`
# geometry column so ad-hoc manual queries (ST_Within / ST_DWithin against
# a boundary or point) run directly on the DB without parsing JSON. Only
# the id, taxon_id, observed_on, lat/long and geometry are promoted to
# columns; everything else stays in raw_data and is reconstructed by the
# flatten layer on read.
#
# This repo is the CACHE. Populating it from the API is the ingest
# pipeline's job (pipelines/ingest_inat.R); consuming it into an
# export-shaped frame is pipelines/read_inat.R's job.
#
# Depends on: DBI, duckdb, jsonlite. Assumes spatial extension already
# loaded by store_connect().
# =============================================================

library(DBI)

# ------------------------------------------------------------
# write_observations(): bulk-upsert ONE page of raw observation objects into
# inat_observations. The whole page is serialized to a single JSON array in
# ONE jsonlite::toJSON call, handed to DuckDB as one string, and unnested +
# parsed inside DuckDB (C++). This is the key performance/robustness fix:
#
#   - ONE toJSON per page (not one per object) -- avoids a per-row R loop
#     over hundreds of large, deeply-nested iNat objects.
#   - DuckDB does the JSON parsing via unnest(CAST(arr AS JSON[])), casting
#     each element once (CTE `c`) and extracting coordinates once.
#   - Geometry via ST_Point(lon, lat) from the extracted DOUBLEs -- much
#     cheaper than re-parsing GeoJSON per row. Stored EPSG:4326 (lon/lat).
#   - Only one page (~200 objects) is ever held in memory. The caller keeps
#     a transaction open across pages and commits every N (see ingest), so
#     commits are batched WITHOUT buffering thousands of objects in R.
# ------------------------------------------------------------
write_observations <- function(con, results) {
  if (length(results) == 0) return(invisible(0L))

  page_json <- as.character(jsonlite::toJSON(results, auto_unbox = TRUE, null = "null"))
  stg <- data.frame(arr = page_json, stringsAsFactors = FALSE)

  duckdb::duckdb_register(con, "stg_obs", stg)
  on.exit(duckdb::duckdb_unregister(con, "stg_obs"), add = TRUE)

  DBI::dbExecute(con, "
    INSERT OR REPLACE INTO inat_observations
    WITH e AS (SELECT unnest(CAST(arr AS JSON[])) AS j FROM stg_obs),
    c AS (
      SELECT j,
        CAST(j->>'$.id' AS BIGINT)                            AS id,
        TRY_CAST(j->>'$.taxon.id' AS BIGINT)                 AS taxon_id,
        TRY_CAST(j->>'$.observed_on' AS DATE)                AS observed_on,
        TRY_CAST(j->>'$.geojson.coordinates[1]' AS DOUBLE)   AS lat,
        TRY_CAST(j->>'$.geojson.coordinates[0]' AS DOUBLE)   AS lon
      FROM e
    )
    SELECT
      id, taxon_id, observed_on, lat, lon,
      CASE WHEN lon IS NOT NULL AND lat IS NOT NULL
           THEN ST_Point(lon, lat) ELSE NULL END,
      j
    FROM c
    WHERE id IS NOT NULL;
  ")
  invisible(length(results))
}

# ------------------------------------------------------------
# Read helpers.
# ------------------------------------------------------------
count_observations <- function(con) {
  DBI::dbGetQuery(con, "SELECT COUNT(*) AS n FROM inat_observations")$n[1]
}

# Highest stored observation id -- the incremental fetch cursor. 0 when empty.
max_observation_id <- function(con) {
  v <- DBI::dbGetQuery(con, "SELECT MAX(id) AS m FROM inat_observations")$m[1]
  if (is.na(v)) 0L else as.integer(v)
}

# Return raw observation JSON strings (id + raw_data) for the flatten layer.
read_observations_raw <- function(con) {
  DBI::dbGetQuery(con, "SELECT id, raw_data FROM inat_observations ORDER BY id")
}
