library(testthat)

# DB-backed tests. Run only where the duckdb R package is installed (e.g. the
# user's Mac). They also need the spatial extension for the geometry column;
# if it can't load (offline first run), the test skips rather than fails.

skip_if_no_store <- function() {
  if (!have_duckdb()) skip("duckdb R package not installed")
}

open_temp_store <- function() {
  src("config.R"); src("db/store_conn.R"); src("db/observations_store.R")
  src("db/taxon_store.R"); src("db/decision_store.R")
  path <- tempfile(fileext = ".duckdb")
  con <- tryCatch(store_connect(path), error = function(e) skip(conditionMessage(e)))
  con
}

test_that("observation upsert is idempotent and tracks the max id cursor", {
  skip_if_no_store()
  con <- open_temp_store(); on.exit(store_disconnect(con), add = TRUE)

  obs <- list(list(
    id = 12345, taxon = list(id = 632955), observed_on = "2021-04-12",
    geojson = list(type = "Point", coordinates = list(-117.24, 32.67))
  ))
  expect_equal(write_observations(con, obs), 1L)
  write_observations(con, obs)  # re-upsert same id
  expect_equal(count_observations(con), 1L)
  expect_equal(max_observation_id(con), 12345L)

  raw <- read_observations_raw(con)
  expect_equal(nrow(raw), 1L)
})

test_that("taxon cache round-trips by id and by name key", {
  skip_if_no_store()
  con <- open_temp_store(); on.exit(store_disconnect(con), add = TRUE)

  expect_null(taxon_cache_get(con, taxon_cache_key_id(1)))
  taxon <- list(id = 632955, name = "Melissodes robustior", rank = "species")
  taxon_cache_put(con, taxon_cache_key_id(632955), 632955, taxon)

  hit <- taxon_cache_get(con, taxon_cache_key_id(632955))
  expect_equal(hit$name, "Melissodes robustior")
  expect_equal(taxon_cache_count(con), 1)
})

test_that("decision store records pick and skip", {
  skip_if_no_store()
  con <- open_temp_store(); on.exit(store_disconnect(con), add = TRUE)

  expect_null(decision_get(con, "Andrena quercina"))
  decision_put(con, "Andrena quercina", "pick", 361408)
  d <- decision_get(con, "Andrena quercina")
  expect_equal(d$action, "pick")
  expect_equal(d$chosen_taxon_id, 361408L)

  decision_put(con, "Foo bar", "skip")
  expect_equal(decision_get(con, "Foo bar")$action, "skip")
})

test_that("ingest_observations buffers pages and bulk-commits all rows", {
  skip_if_no_store()
  con <- open_temp_store(); on.exit(store_disconnect(con), add = TRUE)
  src("api/inat_http.R"); src("api/inat_flatten.R"); src("api/inat_cache.R")
  src("pipelines/ingest_inat.R")

  # fake API: 5 observations, paged 2 at a time by id_above
  recs <- lapply(1:5, function(i) list(
    id = i, taxon = list(id = i * 10), observed_on = "2021-04-12",
    geojson = list(type = "Point", coordinates = list(-117.24 + i * 0.001, 32.67))
  ))
  fake_request <- function(path, query = list(), user_agent = NULL) {
    above <- query$id_above %||% 0
    remaining <- Filter(function(r) r$id > above, recs)
    list(results = head(remaining, query$per_page))
  }

  # commit_every = 1 forces a commit after each page across the 5 rows
  n <- ingest_observations(con, place_id = 1, taxon_id = 1, without_taxon_id = 1,
                           incremental = FALSE, commit_every = 1,
                           request_fn = fake_request, verbose = FALSE)
  expect_equal(n, 5)
  expect_equal(count_observations(con), 5L)
  expect_equal(max_observation_id(con), 5L)
})

test_that("resolve_taxonomy caches: second call makes no API request", {
  skip_if_no_store()
  con <- open_temp_store(); on.exit(store_disconnect(con), add = TRUE)
  src("api/inat_http.R"); src("api/inat_flatten.R"); src("api/inat_cache.R")

  taxon <- jsonlite::fromJSON(fx("taxon_sample.json"), simplifyVector = FALSE)
  calls <- 0
  fake_request <- function(path, query = list(), user_agent = NULL) {
    calls <<- calls + 1
    list(results = list(taxon))
  }

  m1 <- resolve_taxonomy(con, c(632955), request_fn = fake_request, verbose = FALSE)
  expect_equal(m1$taxon_genus_name[1], "Melissodes")
  expect_equal(calls, 1)

  # second resolve hits the cache -> no new request
  m2 <- resolve_taxonomy(con, c(632955), request_fn = fake_request, verbose = FALSE)
  expect_equal(calls, 1)
  expect_equal(m2$taxon_family_name[1], "Apidae")
})
