# =============================================================
# pipelines/read_inat.R
# beescabr pipeline -- consume the cache into an export-shaped data frame
# Created: 2026-07-13 (API + DuckDB rewrite)
#
# The read counterpart to ingest_inat.R. Turns cached observation objects
# into a data frame with the SAME columns the retired CSV export had
# (id, user_login, coords, tag_list, quality, taxon_*_name hierarchy, and
# field:* obs-fields), so native_bee_checklist.R and inat_bee_clean.R only
# had to swap their input source, not their logic.
#
# Two-part assembly:
#   1. flatten each stored observation's raw JSON -> core + field:* columns
#   2. resolve the ranked taxonomy for the unique taxon ids (cached
#      /taxa/{id}) and join it on, filling taxon_kingdom_name ... taxon_subspecies_name
#      that the /observations payload does not carry inline.
#
# Depends on: db/observations_store.R, api/inat_flatten.R, api/inat_cache.R,
# config.R.
# =============================================================

if (!exists("read_observations_raw")) source("scripts/db/observations_store.R")
if (!exists("flatten_observation"))   source("scripts/api/inat_flatten.R")
if (!exists("resolve_taxonomy"))       source("scripts/api/inat_cache.R")
if (!exists("TAXON_RANK_COLUMNS"))     source("scripts/config.R")

library(dplyr)

# ------------------------------------------------------------
# read_observations_export(): build the export-shaped frame from the cache.
# `resolve_taxa = TRUE` joins the ranked taxonomy (needs the taxon cache;
# will fetch on miss). Set FALSE for a fast coordinates/tags-only read that
# skips taxonomy (used by manual QC where only geometry/tags matter).
# ------------------------------------------------------------
read_observations_export <- function(con, resolve_taxa = TRUE,
                                     request_fn = inat_request, verbose = TRUE) {
  raw <- read_observations_raw(con)
  if (nrow(raw) == 0) {
    warning("Observation cache is empty -- run ingest_observations() first.")
    return(tibble())
  }
  if (verbose) message(sprintf("Flattening %d cached observations...", nrow(raw)))

  core <- dplyr::bind_rows(lapply(raw$raw_data, function(j) {
    flatten_observation(jsonlite::fromJSON(j, simplifyVector = FALSE))
  }))

  if (!resolve_taxa) return(core)

  if (verbose) message("Resolving ranked taxonomy from taxon cache...")
  tax_map <- resolve_taxonomy(con, core$taxon_id, request_fn = request_fn, verbose = verbose)

  out <- dplyr::left_join(core, tax_map, by = "taxon_id")

  # Guarantee every export rank column exists even if no observation
  # resolved that rank (keeps downstream select()/rename() from erroring).
  for (col in TAXON_RANK_COLUMNS) {
    if (!col %in% names(out)) out[[col]] <- NA_character_
  }
  out
}
