# =============================================================
# db/observations_store.R
# beescabr pipeline -- observation object repository (DuckDB)
# Created: 2026-07-13 (API + DuckDB rewrite)
#
# Stores raw iNat observation JSON with an extracted spatial `location`
# geometry column so ad-hoc manual queries (ST_Within / ST_DWithin against
# a boundary or point) run directly on the DB without parsing JSON. Only
# the id, taxon_id, observed_on, lat/long and geometry are promoted to
# columns; everything else stays in raw_data and is reconstructed by the
# flatten layer on read.
#
# This repo is the CACHE. Populating it from the API is the ingest
# pipeline's job (pipelines/ingest_inat.R); consuming it into an
# export-shaped frame is pipelines/read_inat.R's job.
#
# Depends on: DBI, duckdb, jsonlite. Assumes spatial extension already
# loaded by store_connect().
# =============================================================

library(DBI)

# ------------------------------------------------------------
# write_observations(): upsert a page of raw observation objects (a list of
# nested lists, straight from the API) into inat_observations. Geometry is
# built from the GeoJSON with the same TRY(ST_GeomFromGeoJSON(...)) pattern
# proven in the Python pipeline, so a malformed/absent geometry stores NULL
# rather than failing the whole batch.
# ------------------------------------------------------------
write_observations <- function(con, results) {
  if (length(results) == 0) return(invisible(0L))

  raw_json <- vapply(results, function(o) jsonlite::toJSON(o, auto_unbox = TRUE, null = "null"),
                     character(1))
  stg <- data.frame(raw = raw_json, stringsAsFactors = FALSE)

  duckdb::duckdb_register(con, "stg_obs", stg)
  on.exit(duckdb::duckdb_unregister(con, "stg_obs"), add = TRUE)

  DBI::dbExecute(con, "
    INSERT OR REPLACE INTO inat_observations
    SELECT
      CAST(raw->>'$.id' AS BIGINT)                                        AS id,
      TRY_CAST(raw->>'$.taxon.id' AS BIGINT)                             AS taxon_id,
      TRY_CAST(raw->>'$.observed_on' AS DATE)                            AS observed_on,
      TRY_CAST(raw->>'$.geojson.coordinates[1]' AS DOUBLE)              AS latitude,
      TRY_CAST(raw->>'$.geojson.coordinates[0]' AS DOUBLE)              AS longitude,
      CASE WHEN raw->>'$.geojson.type' = 'Point'
           THEN TRY(ST_GeomFromGeoJSON(raw->>'$.geojson'))
           ELSE NULL END                                                 AS location,
      CAST(raw AS JSON)                                                   AS raw_data
    FROM stg_obs
    WHERE raw->>'$.id' IS NOT NULL;
  ")
  invisible(length(results))
}

# ------------------------------------------------------------
# Read helpers.
# ------------------------------------------------------------
count_observations <- function(con) {
  DBI::dbGetQuery(con, "SELECT COUNT(*) AS n FROM inat_observations")$n[1]
}

# Highest stored observation id -- the incremental fetch cursor. 0 when empty.
max_observation_id <- function(con) {
  v <- DBI::dbGetQuery(con, "SELECT MAX(id) AS m FROM inat_observations")$m[1]
  if (is.na(v)) 0L else as.integer(v)
}

# Return raw observation JSON strings (id + raw_data) for the flatten layer.
read_observations_raw <- function(con) {
  DBI::dbGetQuery(con, "SELECT id, raw_data FROM inat_observations ORDER BY id")
}
