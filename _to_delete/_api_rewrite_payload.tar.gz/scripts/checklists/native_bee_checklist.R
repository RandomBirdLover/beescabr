# =============================================================
# checklists/native_bee_checklist.R
# beescabr pipeline -- Tier 1 + Tier 2 checklist ORCHESTRATOR
# Rewritten: 2026-07-13 (API + DuckDB rewrite; monolith split into modules)
#
# This file used to be a 1,300-line monolith. It is now a thin top-to-bottom
# runner that wires together the extracted modules:
#   - config.R                     constants
#   - pipelines/ingest_inat.R      API -> DuckDB (the only fetch)
#   - pipelines/read_inat.R        DuckDB -> export-shaped frame
#   - checklists/holway.R          Holway backfill + cross-check keys
#   - checklists/checklist_tiers.R Tier 1 build (spatial split, dedupe, finalize)
#   - checklists/taxonomy_reference.R  bee_taxonomy_lookup.csv
#   - checklists/tier2_merge.R     Tier 2 merged checklists + specimen
#
# Data source: the iNat API via the DuckDB cache. The CSV export is retired
# -- there is no read.csv of an export anywhere in this pipeline anymore.
#
# Run: Rscript scripts/checklists/native_bee_checklist.R
#   Set BEESCABR_SKIP_INGEST=1 to reuse the cache without hitting the API.
# =============================================================

library(dplyr)
library(stringr)
library(sf)

source("scripts/config.R")
source("scripts/utils/utils.R")                 # write_fresh, require_columns
source("scripts/spatial/spatial_utils.R")       # boundaries, PROJECT_CRS
source("scripts/db/store_conn.R")
source("scripts/db/observations_store.R")
source("scripts/db/taxon_store.R")
source("scripts/api/inat_http.R")
source("scripts/api/inat_flatten.R")
source("scripts/api/inat_cache.R")
source("scripts/pipelines/ingest_inat.R")
source("scripts/pipelines/read_inat.R")
source("scripts/checklists/holway.R")
source("scripts/checklists/checklist_tiers.R")
source("scripts/checklists/taxonomy_reference.R")
source("scripts/checklists/tier2_merge.R")

# ------------------------------------------------------------
# STEP 0: cache -- refresh from API (unless skipped) and read export frame.
# ------------------------------------------------------------
con <- store_connect()
on.exit(store_disconnect(con), add = TRUE)

if (Sys.getenv("BEESCABR_SKIP_INGEST", "0") != "1") {
  ingest_observations(con)
} else {
  message("BEESCABR_SKIP_INGEST=1 -- using existing cache (", count_observations(con), " obs)")
}

bees <- read_observations_export(con)

# ------------------------------------------------------------
# STEP 1: rename ranked-name columns to bare names (the rest of the pipeline
# speaks bare names). taxon_id, subgenus, complex, complex_taxon_id and the
# field:* columns are already present from the read.
# ------------------------------------------------------------
bees <- bees |>
  rename(
    kingdom     = taxon_kingdom_name,
    phylum      = taxon_phylum_name,
    class       = taxon_class_name,
    order       = taxon_order_name,
    superfamily = taxon_superfamily_name,
    family      = taxon_family_name,
    subfamily   = taxon_subfamily_name,
    tribe       = taxon_tribe_name,
    genus       = taxon_genus_name,
    species     = taxon_species_name,
    subspecies  = taxon_subspecies_name
  )

# ------------------------------------------------------------
# STEP 2: Holway backfill of blank family/subfamily/tribe.
# ------------------------------------------------------------
holway_df <- load_holway(PATHS$holway_combined)
genus_lookup <- holway_genus_taxonomy(holway_df)
bees <- backfill_taxonomy(bees, genus_lookup)

# ------------------------------------------------------------
# STEP 3: spatial split into the three tiers (SD County / Point Loma / CABR).
# ------------------------------------------------------------
n_missing_coords <- sum(is.na(bees$latitude) | is.na(bees$longitude))
if (n_missing_coords > 0)
  message(sprintf("NOTE: %d obs missing coords -- excluded from all tiers.", n_missing_coords))

bees_sf <- bees |>
  filter(!is.na(latitude), !is.na(longitude)) |>
  st_as_sf(coords = c("longitude", "latitude"), crs = 4326, remove = FALSE) |>
  st_transform(PROJECT_CRS)

message("\n--- Spatial split ---")
bees_sd_county  <- spatial_split(bees_sf, sd_county_boundary,  "SD County")
bees_point_loma <- spatial_split(bees_sf, point_loma_boundary, "Point Loma")
bees_cabr       <- spatial_split(bees_sf, cabr_survey_box,     "CABR")

# ------------------------------------------------------------
# STEP 4: Tier 1 build + finalize (subgenus/complex already resolved).
# ------------------------------------------------------------
message("\n--- Tier 1 build ---")
cl_sd   <- build_checklist(bees_sd_county,  "SD County")
cl_pl   <- build_checklist(bees_point_loma, "Point Loma")
cl_cabr <- build_checklist(bees_cabr,       "CABR")

taxonomy_lookup <- taxonomy_lookup_from_bees(bees)
cl_sd   <- finalize_checklist(cl_sd,   taxonomy_lookup)
cl_pl   <- finalize_checklist(cl_pl,   taxonomy_lookup)
cl_cabr <- finalize_checklist(cl_cabr, taxonomy_lookup)

run_qc(cl_sd,   "SD County")
run_qc(cl_pl,   "Point Loma")
run_qc(cl_cabr, "CABR")

write_fresh(cl_sd,   PATHS$checklist_sd_county_inat)
write_fresh(cl_pl,   PATHS$checklist_point_loma_inat)
write_fresh(cl_cabr, PATHS$checklist_cabr_inat)
message("\nTier 1 checklists written.")

# ------------------------------------------------------------
# STEP 5: bee_taxonomy_lookup.csv.
# ------------------------------------------------------------
message("\n--- bee_taxonomy_lookup ---")
bee_taxonomy_lookup <- build_bee_taxonomy_lookup(holway_df, cl_sd, bees)
write_fresh(bee_taxonomy_lookup, PATHS$taxonomy_lookup, na = "")
message("Wrote ", nrow(bee_taxonomy_lookup), " taxonomy rows.")

# ------------------------------------------------------------
# STEP 6: Tier 2 merged checklists (+ CABR specimen evidence & Holway check).
# ------------------------------------------------------------
if (!file.exists(PATHS$specimen_clean)) {
  message("Specimen clean file missing -- running specimen_bee_clean.R...")
  source("scripts/clean/specimen_bee_clean.R")
}
cabr_specimens <- readr::read_csv(PATHS$specimen_clean, show_col_types = FALSE)
require_columns(cabr_specimens,
                c("order", "family", "subfamily", "tribe", "genus", "subgenus",
                  "complex", "complex_taxon_id", "species", "subspecies"),
                "cabr_specimens")

specimen_species <- specimen_species_table(cabr_specimens)
holway_keys <- holway_match_keys(holway_df)

message("\n--- Tier 2 build ---")
cl_cabr_v2 <- build_tier2_checklist(cl_cabr, specimen_species, holway_keys,
                                    run_holway_check = FALSE, label = "CABR")
cl_pl_v2   <- build_tier2_checklist(cl_pl, NULL, holway_keys,
                                    run_holway_check = FALSE, label = "Point Loma")
cl_sd_v2   <- build_tier2_checklist(cl_sd, NULL, holway_keys,
                                    run_holway_check = TRUE, label = "SD County")

write_fresh(build_specimen_checklist(cabr_specimens), PATHS$checklist_cabr_specimen, na = "")
write_fresh(cl_cabr_v2, PATHS$checklist_cabr_v2, na = "")
write_fresh(cl_pl_v2,   PATHS$checklist_point_loma_v2, na = "")
write_fresh(cl_sd_v2,   PATHS$checklist_sd_county_v2, na = "")

message("\nAll checklists written. Done.")
