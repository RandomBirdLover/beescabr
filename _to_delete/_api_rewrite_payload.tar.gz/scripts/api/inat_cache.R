# =============================================================
# api/inat_cache.R
# beescabr pipeline -- cache-first taxon access + taxonomy resolution
# Created: 2026-07-13 (API + DuckDB rewrite)
#
# The only module that knows about BOTH the API transport and the DuckDB
# taxon cache. Everything above it (checklist build, export read) asks for
# a taxon or a taxonomy map and neither knows nor cares whether it came
# from the network or the cache. Fetches on miss, writes through, returns.
#
# resolve_taxonomy() unifies what used to be two separate things in the old
# code: STEP 1's ranked-name hierarchy AND STEP 4's subgenus/complex fetch.
# Both now come from one cached /taxa/{id} call per taxon via parse_taxon_ranks().
#
# Depends on: api/inat_http.R, api/inat_flatten.R, db/taxon_store.R.
# =============================================================

if (!exists("inat_fetch_taxon_by_id")) source("scripts/api/inat_http.R")
if (!exists("parse_taxon_ranks"))       source("scripts/api/inat_flatten.R")
if (!exists("taxon_cache_get"))          source("scripts/db/taxon_store.R")

# ------------------------------------------------------------
# get_taxon_by_id(): return one taxon object (nested list), cache-first.
# ------------------------------------------------------------
get_taxon_by_id <- function(con, id, request_fn = inat_request, verbose = FALSE) {
  key <- taxon_cache_key_id(id)
  hit <- taxon_cache_get(con, key)
  if (!is.null(hit)) {
    if (verbose) message("  cache hit: taxon ", id)
    return(hit)
  }
  results <- inat_fetch_taxon_by_id(id, request_fn = request_fn)
  taxon <- if (length(results) > 0) results[[1]] else NULL
  if (!is.null(taxon)) taxon_cache_put(con, key, taxon$id %||% id, taxon)
  if (verbose) message("  fetched taxon ", id)
  taxon
}

# ------------------------------------------------------------
# get_taxa_by_name(): return the list of candidate taxa for a name search,
# cache-first. Opportunistically caches each candidate by its own id too,
# so a later get_taxon_by_id() for one of them is a hit.
# ------------------------------------------------------------
get_taxa_by_name <- function(con, name, request_fn = inat_request, verbose = FALSE) {
  key <- taxon_cache_key_name(name)
  hit <- taxon_cache_get(con, key)
  if (!is.null(hit)) {
    if (verbose) message("  cache hit: name '", name, "'")
    return(hit)
  }
  results <- inat_fetch_taxa_by_name(name, request_fn = request_fn)
  taxon_cache_put(con, key, NA_integer_, results)
  for (t in results) {
    if (!is.null(t$id)) taxon_cache_put(con, taxon_cache_key_id(t$id), t$id, t)
  }
  if (verbose) message("  fetched name search '", name, "' (", length(results), " results)")
  results
}

# ------------------------------------------------------------
# resolve_taxonomy(): build the taxon_id -> ranked-name (+ subgenus /
# complex / complex_taxon_id) map for a set of taxon ids, one cached
# /taxa/{id} call each. This is the single source that both the checklist
# build and the export-shaped read use to populate taxon_*_name columns.
# ------------------------------------------------------------
resolve_taxonomy <- function(con, taxon_ids, request_fn = inat_request, verbose = TRUE) {
  taxon_ids <- unique(taxon_ids[!is.na(taxon_ids)])
  if (length(taxon_ids) == 0) {
    return(parse_taxon_ranks(list(id = NA_integer_))[0, ])
  }
  rows <- vector("list", length(taxon_ids))
  for (i in seq_along(taxon_ids)) {
    if (verbose && (i %% 25 == 0 || i == length(taxon_ids))) {
      message(sprintf("  taxonomy: %d / %d", i, length(taxon_ids)))
    }
    taxon <- get_taxon_by_id(con, taxon_ids[[i]], request_fn = request_fn)
    rows[[i]] <- if (is.null(taxon)) {
      r <- parse_taxon_ranks(list(id = taxon_ids[[i]]))
      r
    } else {
      parse_taxon_ranks(taxon)
    }
  }
  dplyr::bind_rows(rows)
}

`%||%` <- function(a, b) if (is.null(a) || length(a) == 0) b else a
