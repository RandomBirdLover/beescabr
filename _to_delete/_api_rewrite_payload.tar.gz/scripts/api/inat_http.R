# =============================================================
# api/inat_http.R
# beescabr pipeline -- iNaturalist API transport
# Created: 2026-07-13 (API + DuckDB rewrite)
#
# Single responsibility: talk HTTP to the iNat API. User-agent, timeout,
# retry/backoff on transient errors, and id-cursor pagination live here and
# NOWHERE else. This layer knows nothing about DuckDB or about how results
# get flattened -- callers pass in a page callback.
#
# The pure pagination-control helpers (.obs_cursor / .obs_page_done) are
# split out so the loop-termination logic is unit-tested without a network.
#
# Depends on: httr2. Sources config.R for defaults.
# =============================================================

library(httr2)

if (!exists("INAT_BASE_URL")) source("scripts/config.R")

# ------------------------------------------------------------
# inat_request(): perform one GET against the iNat API and return parsed
# JSON. Retries transient failures (429 + 5xx) with exponential backoff.
# `perform` is injectable so tests can substitute a fake performer.
# ------------------------------------------------------------
inat_request <- function(path, query = list(),
                         base_url = INAT_BASE_URL,
                         user_agent = INAT_USER_AGENT,
                         timeout = 30,
                         max_tries = 6,
                         perform = req_perform) {
  url <- paste0(sub("/+$", "/", base_url), sub("^/+", "", path))
  req <- request(url) |>
    req_user_agent(user_agent) |>
    req_timeout(timeout) |>
    req_retry(
      max_tries    = max_tries,
      is_transient = function(resp) resp_status(resp) %in% c(429L, 500L, 502L, 503L, 504L),
      backoff      = function(i) min(60, 5 * 2^(i - 1))
    )
  # Drop NULL/empty query params before attaching.
  query <- query[!vapply(query, function(v) is.null(v) || length(v) == 0, logical(1))]
  if (length(query) > 0) req <- req_url_query(req, !!!query)

  resp <- perform(req)
  resp_body_json(resp)
}

# ------------------------------------------------------------
# Pure pagination-control helpers (unit-tested in test-http.R).
# iNat's stable, gap-free paging is by ascending id with id_above as the
# cursor. A page shorter than per_page means we've reached the end.
# ------------------------------------------------------------
.obs_cursor <- function(results) {
  if (length(results) == 0) return(NULL)
  as.integer(results[[length(results)]]$id)
}

.obs_page_done <- function(results, per_page) {
  length(results) == 0 || length(results) < per_page
}

# ------------------------------------------------------------
# inat_paginate_observations(): walk every page of an /observations query,
# handing each page's raw results list to `callback`. Returns the total
# number of results seen. The store-writing side effect lives in the
# callback, keeping this function I/O-agnostic beyond the HTTP itself.
# ------------------------------------------------------------
inat_paginate_observations <- function(query, callback,
                                       per_page = 200L,
                                       throttle = INAT_THROTTLE_SEC,
                                       user_agent = INAT_USER_AGENT,
                                       start_id = 0L,
                                       request_fn = inat_request,
                                       sleep_fn = Sys.sleep,
                                       verbose = TRUE) {
  query$per_page <- per_page
  query$order_by <- "id"
  query$order    <- "asc"

  total <- 0L
  page  <- 0L
  id_above <- as.integer(start_id)

  repeat {
    page <- page + 1L
    q <- query
    q$id_above <- id_above
    resp <- request_fn("observations", query = q, user_agent = user_agent)
    results <- resp$results %||% list()

    if (length(results) == 0) break

    callback(results)
    total <- total + length(results)

    cur <- .obs_cursor(results)
    if (verbose) message(sprintf("  page %d: %d obs (id up to %s), %d total",
                                 page, length(results), cur, total))
    if (.obs_page_done(results, per_page)) break
    id_above <- cur
    if (!is.null(throttle) && throttle > 0) sleep_fn(throttle)
  }
  total
}

# ------------------------------------------------------------
# Thin taxon endpoints used by the cache layer.
# ------------------------------------------------------------
inat_fetch_taxon_by_id <- function(id, request_fn = inat_request) {
  resp <- request_fn(paste0("taxa/", id), query = list(all_names = "true"))
  resp$results
}

inat_fetch_taxa_by_name <- function(name, request_fn = inat_request) {
  resp <- request_fn("taxa", query = list(q = name, all_names = "true"))
  resp$results
}

`%||%` <- function(a, b) if (is.null(a) || length(a) == 0) b else a
