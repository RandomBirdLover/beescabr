library(testthat)

test_that("pagination cursor + done helpers behave", {
  src("api/inat_http.R")
  results <- list(list(id = 10), list(id = 20), list(id = 30))
  expect_equal(.obs_cursor(results), 30L)
  expect_null(.obs_cursor(list()))
  # a full page is not done; a short page is done
  expect_false(.obs_page_done(results, per_page = 3))
  expect_true(.obs_page_done(results, per_page = 5))
  expect_true(.obs_page_done(list(), per_page = 5))
})

test_that("inat_paginate_observations walks pages with a fake request_fn", {
  src("api/inat_http.R")

  # Fake API: 5 records total, per_page 2 -> pages of [1,2],[3,4],[5]
  all_records <- lapply(1:5, function(i) list(id = i))
  fake_request <- function(path, query = list(), user_agent = NULL) {
    above <- query$id_above %||% 0
    per   <- query$per_page
    remaining <- Filter(function(r) r$id > above, all_records)
    list(results = head(remaining, per))
  }

  seen <- list()
  total <- inat_paginate_observations(
    query = list(place_id = 1),
    callback = function(res) seen[[length(seen) + 1]] <<- res,
    per_page = 2L,
    throttle = 0,
    request_fn = fake_request,
    sleep_fn = function(...) invisible(NULL),
    verbose = FALSE
  )

  expect_equal(total, 5)
  expect_equal(length(seen), 3)              # three pages
  expect_equal(length(seen[[3]]), 1)         # last page has one record
})
